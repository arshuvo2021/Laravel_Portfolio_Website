

<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row">
    <div class="col-md-12 p-5">
    <table id="VisitorDt" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th class="th-sm">NO</th>
          <th class="th-sm">IP</th>
          <th class="th-sm">Date & Time</th>
        </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $VisitorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitorData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            <td><?php echo e($VisitorData->id); ?></td>
            <td><?php echo e($VisitorData->ip_address); ?></td>
            <td><?php echo e($VisitorData->visit_time); ?></td>
          </tr>
              
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    
    </div>
    </div>
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CR_Shuvo\OneDrive\Desktop\Laravel Portfolio Website\admin\resources\views/Visitor.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

   <?php echo $__env->make('Component.HomeBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('Component.HomeService', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CR_Shuvo\OneDrive\Desktop\Laravel Portfolio Website\site\resources\views/Home.blade.php ENDPATH**/ ?>
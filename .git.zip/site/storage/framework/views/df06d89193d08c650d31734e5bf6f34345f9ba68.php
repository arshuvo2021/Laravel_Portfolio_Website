
<div class="container-fluid jumbotron mt-5 ">
    <div class="row">
        <div class="col-md-6 justify-content-center">
            <div class="m-lg-5 m-md-5 p-lg-5 m-sm-3 p-sm-3 p-md-5">
                <h1 class="top-banner-title text-justify">সার্ভিস্ নিন আপনার সময় মত </h1>
                <h1 class="top-banner-subtitle text-justify">প্রফেশনালদের কাছে শিখুন, প্রজেক্ট ভিত্তিক সোর্স কোড সংগ্রহ করুন </h1>

                <a target="_blank" href="https://www.youtube.com/channel/UCSMFY8_rooijS-Zv43tKCrQ"><img class="" src="images/playbtn.svg"></a>
            </div>
        </div>
        <div class="col-md-6">
            <img  class="top-banner-img  animated fadeIn" src="images/bannerImg.png">
        </div>
    </div>
</div>
<?php /**PATH C:\Users\CR_Shuvo\OneDrive\Desktop\Laravel Portfolio Website\site\resources\views/Component/HomeBanner.blade.php ENDPATH**/ ?>
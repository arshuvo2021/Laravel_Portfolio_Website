@extends('Layout.app')

@section('content')

   @include('Component.HomeBanner')
   @include('Component.HomeService')

    @endsection
